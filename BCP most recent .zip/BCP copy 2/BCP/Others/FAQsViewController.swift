//
//  FAQsViewController.swift
//  BCP
//
//  Created by Kwesi Adu Cobbina on 22/02/2019.
//  Copyright © 2019 Kwesi Adu Cobbina. All rights reserved.
//

import UIKit
import WebKit

class FAQsViewController: UIViewController {
	
	@IBOutlet weak var faqsWebView: WKWebView!
	
    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
