//
//  NotificationsViewController.swift
//  BCP
//
//  Created by Kwesi Adu Cobbina on 13/02/2019.
//  Copyright © 2019 Kwesi Adu Cobbina. All rights reserved.
//

import UIKit

class NotificationsViewController: UIViewController {

	@IBOutlet weak var notifTableView: UITableView!
	override func viewDidLoad() {
        super.viewDidLoad()

		
		
    }
    

	

}
